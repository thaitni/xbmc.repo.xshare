# -*- coding: UTF-8 -*-
from xshare.utils import *
HANDLE=int(sys.argv[1])
PATH='plugin://plugin.video.xshare.tiny'
fshareSite='www.fshare.vn'

addon = xbmcaddon.Addon()
home = addon.getAddonInfo('path')
icon = os.path.join(home,'icon.png')
iconPath = os.path.join(home,'resources','icon')

def ico(s):return os.path.join(home,'resources','icon',s)
def add_sep_item(s):addir(namecolor('{:-^80}'.format(s),'lime'),'sepItem',icon,'No',1)
def addir(name,href,img='',mode='',page=1,query='',isFolder=False,menu=[]):
	if not img:img=icon
	listitem=xbmcgui.ListItem(name,iconImage=img,thumbnailImage=img)
	if not isFolder and href!='sepItem':
		listitem.setInfo(type="video",infoLabels={})
		listitem.setProperty('IsPlayable', 'true')
	if menu:
		if isinstance(menu,basestring):href+='|%s'%menu
		else:listitem.addContextMenuItems(addMenu(menu))
	args={'name':name,'url':href,'img':img,'mode':mode,'page':page,'query':query}
	xbmcplugin.addDirectoryItem(HANDLE,PATH+'?'+urllib.urlencode(args),listitem,isFolder)

def addMenu(menu):
	items=[]
	for item in menu:
		label,name,href,img,mode,page,query=item
		arg={'name':u2s(name),'url':href,'img':img,'mode':mode,'page':page,'query':query}
		command='RunPlugin(%s?%s)'%(PATH,urllib.urlencode(arg))
		if 'Remove' in query or 'Delete' in query:label=namecolor(label,'red')
		else:label=namecolor(label,'lime')
		items.append((label,command))
	return items

def addirFshare(label,href,img,menu=[]):
	label=s2c(label)
	href=href.replace('http:','https:')
	if not img:img=ico('fshare.png')
	if '/file/' in href:
		label=namecolor('Fshare ','gold')+label
		addir(label,href.replace('http:','https:'),img,'fsharePlay',1,'',False,menu)	
	else:
		label=namecolor(label,'gold')
		addir(label,href.replace('http:','https:'),img,'fshareFolder',1,'',True,menu)	

def inputLink():
	result=False
	href=get_input('Hãy nhập link/ID Fshare')
	if not href or not href.strip():pass
	elif len(href.strip())<10:
		mess('Bạn nhập ID link chưa đúng: '+href)
	else:
		from xshare.myclass import fshare
		fs=fshare()
		href,label=fs.checkLink(href)
		if href:
			result=True
			if not myData.get(href):
				myData[href]=label
				xrw('xsharetiny.json',json.dumps(myData))
			addirFshare(label,href,img)
	return result

def searchResult(query):
	if '*#*' in query:start=query.split('*#*')[1];query=query.split('*#*')[0]
	else:start='0'
	from xshare.myclass import googleSearch
	ggs=googleSearch()
	items=ggs.content('009789051051551375973:xekpkwarjri',start,query)
	for title,href,img in items:
		menu=[('Thêm tên mục này vào danh mục search',title,'search',href,'menuAction',1,'Add'),
				('Thêm mục này vào Home List',title,href,'','menuAction',1,'toHome')]
		if 'Page next:' in title:
			page=img;start=href;query=query+'*#*'+start
			addir(title,url,icon,mode,page,query,True)
		elif 'fcine.net' in href:
			title=namecolor('fcine ','orangered')+title
			addir(title,href,img,'fcine.net',1,'',True,menu)			
		elif 'taiphimhd.net' in href:
			title=namecolor('taiphimhd ','FF1E90FF')+title
			addir(title,href,img,'taiphimhd.net',1,'Link',True,menu)
		elif 'fsharefilm.com' in href:
			title=namecolor('fsharefilm ','FFF08080')+title
			addir(title,href,img,'fsharefilm.com',1,'',True,menu)
		elif 'fshare.vn' in href:addirFshare(title,href,img,menu)
		elif 'vaphim.com' in href:
			title=namecolor('vaphim ','gold')+title
			addir(title,href,img,'vaphim.com',1,'',True,menu)
		else:mess('Xshare chưa nhận diện được:%s'%href)
	return items

def fsharePlay(url):
	def getLink(url):
		fs=fshare()
		link=''
		user,passwd=addon.getSetting('username'),addon.getSetting('password')
		fs.login(user,passwd)
		if fs.logged:link=fs.getLink(url);fs.logout()
		if not link and link!='Failed':
			b=requests.get('https://www.fshare.vn/folder/YZPA4C7MABDP').content
			cookie=xsearch('data-path="/(.+?)"',b)
			if cookie:
				link=fs.getLink(url, cookie)
			if link and link!='Failed':
				mess(namecolor('Thanks to https://www.facebook.com/xshare.vn','cyan'))
			elif not link:
				link=fs.getLinkByAcc(url, getXshareData().get('fshare',[]))
		return link
	
	from xshare.myclass import fshare
	if '|' in url:
		subUrl=url.split('|')[1]
		url=url.split('|')[0]
		if 'www.fshare.vn' in subUrl:url=[url,subUrl];subUrl=''
	else:subUrl=''
	
	result=False
	link=getLink(url)
	if link and isinstance(link,list):subUrl=link[1];link=link[0]
	try:ext=link.rsplit('.',1)[1]
	except:ext=' '
	if ext.lower() in ['srt','sub','txt','smi','ssa','ass','nfo']:
		try:filename=namecolor(name).rsplit(' ',1)[1]
		except:filename=namecolor(name)
		downloadSubs(link,filename)
		xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem(None))
	elif link and link!='Failed':
		result=True
		item=xbmcgui.ListItem(path=link)
		if subUrl:
			deleteSubs()
			subFile=os.path.join(xshareSub,'vie.srt')
			try:urllib.urlretrieve(subUrl,subFile)
			except:pass
			subUrl=[subFile]
		else:
			subUrl=[]
			for f in os.listdir(xshareSub):
				sf=os.path.join(xshareSub,f)
				if re.split('\.|-| ',f.lower())[0] in link.lower():subUrl.append(sf)
		if subUrl:
			if len(subUrl)>1:mess('Xshare auto loaded [COLOR cyan]Multi subtitles[/COLOR]')
			else:mess('Xshare auto loaded subtitles')
			item.setSubtitles(subUrl);xbmc.sleep(1000)
		xbmcplugin.setResolvedUrl(HANDLE,True,item)
		#if subUrl:setSubtitles(subUrl)
	else:xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem(None))
	return result
	
xbmcplugin.setContent(HANDLE, 'movies')
name,url,img,mode,page,query=get_params(sys.argv[2])
end=True
try:myData=json.loads(xrw('xsharetiny.json'))
except:myData={}

if not mode:
	label=namecolor('Google Search phim Fshare','lime')
	addir(label,'',ico('gsearch.png'),'search',1,'search',True)
	addir(namecolor('Nhập link/ID Fshare','orange'),'',ico('fshare.png'),'inputLink',1,'',True)
	items=[i for i in myData.keys() if i!='searchString']
	if items:
		add_sep_item('-')
		for href in items:
			title=u2s(myData.get(href))
			menu=[('Đổi tên mục này',title,href,'','menuAction',1,'Rename'),
				('Xóa mục này',title,href,'','menuAction',1,'Remove')]
			if 'fcine.net' in href:
				title=namecolor('fcine ','orangered')+title
				addir(title,href,img,'fcine.net',1,'',True,menu)			
			elif 'taiphimhd.net' in href:
				title=namecolor('taiphimhd ','FF1E90FF')+title
				addir(title,href,img,'taiphimhd.net',1,'Link',True,menu)
			elif 'fsharefilm.com' in href:
				title=namecolor('fsharefilm ','FFF08080')+title
				addir(title,href,img,'fsharefilm.com',1,'',True,menu)
			elif 'fshare.vn' in href:addirFshare(title,href,img,menu)
			elif 'vaphim.com' in href:
				title=namecolor('vaphim ','gold')+title
				addir(title,href,img,'vaphim.com',1,'',True,menu)
			#addirFshare(title,href,img,menu)
	deleteSubs()

elif mode=='search':
	if query=='search':
		label=namecolor('Nhập chuổi tìm kiếm mới','orange')
		addir(label,'',ico('gsearch.png'),mode,1,'input',True)
		sringSearch=myData.get('searchString',[])
		for i in range(len(sringSearch)):
			name=u2s(sringSearch[i])
			menu=[('Đổi tên mục này',name,'search','','menuAction',i,'Rename'),
				('Xóa mục này',name,'search','','menuAction',i,'Remove')]
			addir(name,'',ico('gsearch.png'),mode,1,name,True,menu)

	else:
		if query=='input':query=get_input('Hãy nhập chuổi tên phim cần tìm')
		if query:
			if not myData.has_key('searchString'):
				myData['searchString']=[query]
				xrw('xsharetiny.json',json.dumps(myData))
			elif '*#*' not in query and s2u(query) not in myData['searchString']:
				myData['searchString'].append(query)
				xrw('xsharetiny.json',json.dumps(myData))
			end=searchResult(query)
		else:end=False

elif mode=='inputLink':end=inputLink()
elif mode=='fshareFolder':
	from xshare.myclass import fshare
	fs=fshare()
	items=fs.getFolder(url)
	if not items:
		end=False
		mess('Thư mục rỗng/không tồn tại!')
	else:[addirFshare(label,href,img) for label,href in items]

elif mode=='menuAction':
	if url=='search' and query=='Rename':
		label=get_input('Hãy nhập tên mới',namecolor(name))
		if label and label.strip() and label.strip()!=namecolor(name):
			myData['searchString'][page]=label.strip()
			xrw('xsharetiny.json',json.dumps(myData))
			mess('Đã sửa tên 1 mục')
			xbmc.executebuiltin("Container.Refresh")
	elif url=='search' and query=='Remove':
		try:
			myData['searchString'].pop(page)
			xrw('xsharetiny.json',json.dumps(myData))
			mess('Đã xóa mục '+namecolor(name))
			xbmc.executebuiltin("Container.Refresh")
		except:pass
	elif url=='search' and query=='Add':
		myData['searchString'].append(namecolor(name))
		xrw('xsharetiny.json',json.dumps(myData))
		mess('Đã thêm 1 chuổi vào danh mục search')
	
	elif query=='toHome':
		if myData.has_key(url):mess('Mục này đã có trong Home List!')
		else:
			myData[url]=name
			xrw('xsharetiny.json',json.dumps(myData))
			mess('Đã thêm 1 mục vào Home List')
	elif query=='Rename':
		label=get_input('Hãy nhập tên mới',namecolor(name))
		if label and label.strip() and label.strip()!=namecolor(name):
			myData[url]=label.strip()
			xrw('xsharetiny.json',json.dumps(myData))
			mess('Đã sửa tên 1 mục')
			xbmc.executebuiltin("Container.Refresh")
	elif query=='Remove':
		try:
			myData.pop(url)
			xrw('xsharetiny.json',json.dumps(myData))
			mess('Đã xóa mục '+namecolor(name))
			xbmc.executebuiltin("Container.Refresh")
		except:pass
elif mode=='fsharePlay':end=fsharePlay(url)
elif mode=='vaphim.com':
	items=[]
	if '/tag/' in url:url=xsearch('class="entry-title"><a href="([^"]+?)"',xread(url))
	b=xread(url)
	name=namecolor(name.replace('Vaphim ',''))
	b=xsearch('<div id="post-(.+?)"fb-comments"',b,1,re.S)
	if re.search('class=".+category-(game|phn-mm|ebooks).+"',b):
		mess('Sorry! Trang này không phải trang phim','Vaphim.com')
	if not img or 'xshare' in img:img=xsearch('"image" content="(.+?)"',b)
	items=[i for i in re.findall('(<a.+?/a>)',b) if re.search(fshareSite+'/[file|folder]',i)]
	items=[(re.sub('<.+?>','',i),xsearch('([\w|:|/]+?%s[\w|:|/]+)'%fshareSite,i)) for i in items]
	if items:#Phụ Đề Việt
		sub=[i[1] for i in items if re.search('Phụ Đề Việt',i[0]) and '/file/' in i[1]]
		if len(sub)==1:
			items=[i for i in items if sub[0] not in i[1]]
			sub='|'+sub[0];mess('Xshare sẽ tự động load phụ đề')
		else:sub=''
		for label,href in items:
			addirFshare(label,href+sub,img)
	else:mess('Không tìm thấy link Fshare');end=False

elif mode=='fcine.net':
	from xshare.myclass import fcine
	fc=fcine()
	items=fc.getFshare(url)
	if items:
		for label,href,sub in items:addirFshare(label,href,img,sub)
	else:mess('Không tìm thấy link Fshare');end=False

elif mode=='taiphimhd.net':
	if query=='Link':
		from xshare.myclass import taiphimhd
		tp=taiphimhd()
		items=tp.getFshare(url)
		if items:
			for label,href in items:
				if fshareSite in href:addirFshare(label,href,img)
				else:addir(namecolor('Sub ','FF448EE4')+label,href,icon,mode,1,'Sub',True)
		else:mess('Không tìm thấy link Fshare');end=False
	else:
		try:filename=namecolor(name).rsplit(' ',1)[1]
		except:filename=namecolor(name)
		downloadSubs(url,filename)
		end=False

elif mode=='fsharefilm.com':
	b=xread(url)
	if not img or 'xshare' in img:
		img=xsearch('("image":\{.+?\})',b,1,re.S)
		img=xsearch('"url":"(.+?)"',img)
	items=[i for i in re.findall('(<a.+?/a>)',b) if re.search(fshareSite+'/[file|folder]',i)]
	items=[(re.sub('<.+?>','',i),xsearch('([\w|:|/]+?%s[\w|:|/]+)'%fshareSite,i)) for i in items]
	for label,href in items:
		addirFshare(label,href,img)

if end:xbmcplugin.endOfDirectory(HANDLE)